/* ==================================================
   ADMIN.JS — For Admin Dashboard Interactions
   ================================================== */

// ✅ Real-time Patient & Doctor Tracker (Admin 1)
setInterval(() => {
  fetch("php/admin_realtime_status.php")
    .then((res) => res.json())
    .then((data) => {
      document.getElementById("totalPatients").textContent = data.total_patients;
      document.getElementById("totalDoctors").textContent = data.total_doctors;
      document.getElementById("totalAppointments").textContent = data.total_appointments;
    })
    .catch((err) => console.error("Realtime update error:", err));
}, 3000); // every 3 seconds

// ✅ Appointment History Table Refresh (Admin 5)
function loadAppointmentHistory() {
  fetch("php/admin_appointments.php")
    .then((res) => res.text())
    .then((html) => {
      document.getElementById("appointmentHistoryTable").innerHTML = html;
    })
    .catch((err) => console.error(err));
}
if (document.getElementById("appointmentHistoryTable")) {
  setInterval(loadAppointmentHistory, 5000);
}

// ✅ Session Log Tracker (Admin 6)
function loadSessionLogs() {
  fetch("php/admin_session_log.php")
    .then((res) => res.text())
    .then((html) => {
      document.getElementById("sessionLogTable").innerHTML = html;
    });
}
if (document.getElementById("sessionLogTable")) {
  setInterval(loadSessionLogs, 4000);
}

// ✅ Search Function (Admin 7)
const searchInput = document.getElementById("adminSearch");
if (searchInput) {
  searchInput.addEventListener("keyup", () => {
    const term = searchInput.value.toLowerCase();
    document.querySelectorAll("#adminTable tbody tr").forEach((row) => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(term) ? "" : "none";
    });
  });
}
